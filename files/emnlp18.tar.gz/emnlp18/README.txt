Included with this README is the response pattern data set used for our sentiment IRT analysis.

If you use the data, please cite the following paper:

J.P. Lalor, H. Wu, T. Munkhdalai, H. Yu. Understanding Deep Learning Performance through an Examination of Test Set Difficulty: A Psychometric Case Study. In EMNLP 2018.

The response_patterns.csv contains the response patterns of 1000 Amazon Mechanica Turk workers for 131 sentiment analysis phrases.

Questions: email lalor at cs dot umass dot edu
