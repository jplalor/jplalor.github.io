This is the version 1.0 distribution of the ComprehENotes question set.

If you use this data please cite the following:

@inproceedings{lalor2017ehrcomprehension,
  title={Generating a Test of Electronic Health Record Narrative Comprehension with Item Response Theory},
  author={Lalor, John P and Wu, Hao and Chen, Li and Mazor, Kathleen and Yu, Hong},
  booktitle={AMIA Annual Symposium Proceedings},
  volume={2017},
  year={2017},
  organization={American Medical Informatics Association}
}

If you have any questions about the dataset, email lalor@cs.umass.edu

The ComprehENotes zip includes the following files:

- this README.txt file

- ComprehENotes_Test_and_Instructions.pdf: The ComprehENotes question set packaged as a standalone test that can be administered offline. This file includes an answer key.

- ComprehENotes_1.0.tsv: TSV file with the ComprehENotes question set. The headers are:
question_id
disease_topic
question_text
option_a
option_b
option_c
correct_answer

- irt_model.rds: An R data file that includes the IRT model for evaluating ComprehENotes response patterns. To get an individual's ability estimate, in R:

library(mirt)  # required package
load('irt_model.rds')

# rp is a vector (1x55) of binary responses (correct/incorrect)
theta <- fscores(irt_model, response.pattern=rp)

# theta will be a vector (1x57), column 56 is estimated ability
theta[,56]

# column 57 is the standard deviation
