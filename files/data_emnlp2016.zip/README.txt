Included here is the data used for the following paper:

John P. Lalor, Hao Wu, Hong Yu, Building an Evaluation Scale using Item Response Theory, EMNLP 2016.

Included are response patterns obtained from Amazon Mechanical Turk (AMT) workers (referred to as Turkers).

The included files are as follows:
irt_file_{4,5}.csv - The raw responses obtained from AMT for the {Group 4, Group 5} items (see the paper for how the data split is designed). Lines are comma separated with headers.

irt_file_{4,5}_coded.csv - The responses, converted to binary correct/incorrect response patterns as required for IRT modeling. Lines are comma separated with headers.

group_{4,5}.txt - The gold standard labels for our test set items, used to generate the coded response patterns. Format is pair_id SPACE label

If you have any questions, please get in touch! lalor at cs dot umass dot edu
